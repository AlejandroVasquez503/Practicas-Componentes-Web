<template>
    <div class="login-container">
        <form @submit.prevent="handleLogin" class="login-form">
            <h2>Login</h2>
            <input class="input-field" type="text" v-model="Username" placeholder="Username" required />
            <input class="input-field" type="password" v-model="Password" placeholder="Password" required />
            <button type="submit-button" class="submit-button">Iniciar Sesion</button>'
            <p v-if="error" class="error-message">{{ error }}</p>
        </form>
    </div>
</template>

<script setup>
    import { ref } from "vue";
    import {useAuthStore} from "../stores/auth";
    import { useRouter } from "vue-router";

    const Username = ref('');
    const Password = ref('');
    const error = ref('');
    const auth = useAuthStore();
    const router = useRouter();

    const handleLogin = async () =>{
        const success = await auth.login(Username.value, Password.value);
        if (success){
            router.push( '/dashboard');
        } else {
            error.value = 'Invalid username or password';
        }
    }
</script>

<style scoped>

.login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f9;
}

.login-form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
}

.login-form h2 {
    margin-bottom: 20px;
    text-align: center;
    text-align: center;
}

.input-field {
    width: 93.5%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
}

.input-field:focus {
    border-color: #007bff;
    outline: none;
}

.submit-button {
    width: 100%;
    padding: 12px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
}

.submit-button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    text-align: center;
    margin-top: 10px;
}

</style>