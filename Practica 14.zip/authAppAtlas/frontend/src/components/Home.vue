<template>
  <h1>Inicio público</h1>
</template>
