<script setup>
import pokedex from './components/pokedex.vue'
</script>

<template>
  <div>
    <pokedex/>
  </div>
</template>

<style scoped>

</style>
