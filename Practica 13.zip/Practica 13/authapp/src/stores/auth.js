import { defineStore } from 'pinia';

export const useAuthStore = defineStore('auth', {
    state: () => ({
        user: null,
        token: localStorage.getItem('token') || null,
    }),

    actions: {
        async login(email, password){
            if(email === 'admin' && password === 'admin'){
                this.user = { name: 'Admin', email };
                this.token = 'fake-jwt-token';
                localStorage.setItem('token', this.token);
                return true;
            }
            return false;
        },

        async logout(){
            this.user = null;
            this.token = null;
            localStorage.removeItem('token');
        },
    },
});