<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const pokemons = ref([])

onMounted(async () => {
  const res = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=20')
  const results = res.data.results

  const promises = results.map(async (poke) => {
    const data = await axios.get(poke.url)
    return {
      id: data.data.id.toString().padStart(3, '0'),
      name: data.data.name.charAt(0).toUpperCase() + data.data.name.slice(1),
      image: data.data.sprites.other['official-artwork'].front_default,
      types: data.data.types.map(t => t.type.name)
    }
  })

  pokemons.value = await Promise.all(promises)
})
</script>


<template>
   <div class="pokedex-container">
    <h1>Pokédex en Vue.js</h1>
    <p>Ejemplo de consumo de PokeAPI con Composition API</p>
    <div class="grid">
      <div v-for="pokemon in pokemons" :key="pokemon.id" class="pokemon-card">
        <img :src="pokemon.image" :alt="pokemon.name" />
        <h3>{{ pokemon.name }}</h3>
        <p>#{{ pokemon.id }}</p>
        <div class="pokemon-types">
          <span
            v-for="type in pokemon.types"
            :key="type"
            :class="type.toLowerCase()"
          >
            {{ type }}
          </span>
        </div>
      </div>
    </div>
    <footer>Creado con Vue.js y PokeAPI</footer>
  </div>
  </template>
  

<style scoped>
.pokedex-container {
  text-align: center;
}

h1 {
  background: #f44336;
  color: white;
  padding: 1rem;
  margin-bottom: 0.5rem;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  padding: 2rem;
}

.pokemon-card {
  background: white;
  color: black;
  border-radius: 10px;
  padding: 1rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  text-align: center;
  transition: transform 0.2s;
}

.pokemon-card:hover {
  transform: translateY(-5px);
}

.pokemon-card img {
  width: 100px;
  height: 100px;
  object-fit: contain;
}

.pokemon-types span {
  display: inline-block;
  margin: 2px;
  padding: 2px 8px;
  border-radius: 10px;
  color: white;
  font-size: 0.8rem;
}

.pokemon-types .grass { background-color: #78C850; }
.pokemon-types .poison { background-color: #A040A0; }
.pokemon-types .fire { background-color: #F08030; }
.pokemon-types .water { background-color: #6890F0; }
.pokemon-types .bug { background-color: #A8B820; }
.pokemon-types .flying { background-color: #A890F0; }
.pokemon-types .normal { background-color: #A8A878; }

footer {
  margin-top: 2rem;
  padding: 1rem;
  background: #222;
  color: white;
}

</style>